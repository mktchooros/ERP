// Real product data from การผลิตยายปู.xlsx — generated

// 📅 แปลงวันที่ทุก format → DD/MM/YYYY (ค.ศ. สากล) เช่น 29/06/2026
function fmtDateGlobal(d) {
  if (!d) return "—";
  const s = String(d).trim();
  const MONTHS = {"ม.ค.":1,"ก.พ.":2,"มี.ค.":3,"เม.ย.":4,"พ.ค.":5,"มิ.ย.":6,"ก.ค.":7,"ส.ค.":8,"ก.ย.":9,"ต.ค.":10,"พ.ย.":11,"ธ.ค.":12,
    "มกราคม":1,"กุมภาพันธ์":2,"มีนาคม":3,"เมษายน":4,"พฤษภาคม":5,"มิถุนายน":6,"กรกฎาคม":7,"สิงหาคม":8,"กันยายน":9,"ตุลาคม":10,"พฤศจิกายน":11,"ธันวาคม":12};
  let day, month, year;
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);          // ISO YYYY-MM-DD
  if (m) { year = +m[1]; month = +m[2]; day = +m[3]; }
  if (year == null) { m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/); if (m) { day = +m[1]; month = +m[2]; year = +m[3]; } } // DD/MM/YYYY
  if (year == null) {                                       // Thai month name
    for (const name in MONTHS) {
      const re = new RegExp("(\\d{1,2})\\s*" + name.replace(/\./g, "\\.") + "(?:\\s*(\\d{4}))?");
      const mm = s.match(re);
      if (mm) { day = +mm[1]; month = MONTHS[name]; year = mm[2] ? +mm[2] : new Date().getFullYear(); break; }
    }
  }
  if (year == null || !month || !day) return s;             // fallback
  if (year > 2400) year -= 543;                             // พ.ศ. → ค.ศ.
  else if (year < 100) year += 1957;                        // yy ย่อ (69 → 2026)
  return String(day).padStart(2, "0") + "/" + String(month).padStart(2, "0") + "/" + year;
}
if (typeof window !== "undefined") window.fmtDateGlobal = fmtDateGlobal;


const TODAY = "18 พฤษภาคม 2569";
const MONTH_LABEL = "พ.ค. 2569";

// 📖 เมนู — สินค้าที่ผลิตและขาย
const MENU = [
  { code: "P01", name: "ผงหมักไก่ย่างแดง 30 กรัม", flavor: "แดง", size: 30, emoji: "🍗", unit: "ซอง", price: 19, cost: 1.23, barcode: "8857129305019" },
  { code: "P02", name: "ผงหมักไก่ย่างแดงปรุงรสสำเร็จรูป 60 กรัม", flavor: "แดง", size: 60, emoji: "🍗", unit: "ซอง", price: 39, cost: 10.48, barcode: "8857129305026" },
  { code: "P03", name: "ผงหมักไก่ย่างแดงปรุงรสสำเร็จรูป 100 กรัม", flavor: "แดง", size: 100, emoji: "🍗", unit: "ซอง", price: 49, cost: 4.38, barcode: "8857129305033" },
  { code: "P04", name: "ผงหมักไก่ย่างแดงปรุงรสสำเร็จรูป 650 กรัม", flavor: "แดง", size: 650, emoji: "🍗", unit: "ซอง", price: 249, cost: 25.55, barcode: "8857129305040" },
  { code: "P05", name: "ผงหมักไก่ย่างแดงปรุงรสสำเร็จรูป 1000 กรัม", flavor: "แดง", size: 1000, emoji: "🍗", unit: "ซอง", price: 350, cost: 44.98, barcode: "8857129305057" },
  { code: "P06", name: "ผงหมักไก่ทอดหาดใหญ่ 30 กรัม", flavor: "หาดใหญ่", size: 30, emoji: "🍤", unit: "ซอง", price: 19, cost: 2.77 },
  { code: "P07", name: "ผงหมักไก่ทอดหาดใหญ่ปรุงรสสำเร็จรูป 60 กรัม", flavor: "หาดใหญ่", size: 60, emoji: "🍤", unit: "ซอง", price: 39, cost: 5.53 },
  { code: "P08", name: "ผงหมักไก่ทอดหาดใหญ่ปรุงรสสำเร็จรูป 100 กรัม", flavor: "หาดใหญ่", size: 100, emoji: "🍤", unit: "ซอง", price: 49, cost: 10.59 },
  { code: "P09", name: "ผงหมักไก่ทอดหาดใหญ่ปรุงรสสำเร็จรูป 650 กรัม", flavor: "หาดใหญ่", size: 650, emoji: "🍤", unit: "ซอง", price: 249, cost: 39.69 },
  { code: "P10", name: "ผงหมักไก่ทอดหาดใหญ่ปรุงรสสำเร็จรูป 1000 กรัม", flavor: "หาดใหญ่", size: 1000, emoji: "🍤", unit: "ซอง", price: 350, cost: 111.80 },
  { code: "P11", name: "ผงหมักทอดนุ่ม 30 กรัม", flavor: "ทอดนุ่ม", size: 30, emoji: "🥘", unit: "ซอง", price: 19, cost: 2.32 },
  { code: "P12", name: "ผงหมักทอดนุ่มปรุงรสสำเร็จรูป 60 กรัม", flavor: "ทอดนุ่ม", size: 60, emoji: "🥘", unit: "ซอง", price: 39, cost: 4.99 },
  { code: "P13", name: "ผงหมักทอดนุ่มปรุงรสสำเร็จรูป 100 กรัม", flavor: "ทอดนุ่ม", size: 100, emoji: "🥘", unit: "ซอง", price: 49, cost: 5.21 },
  { code: "P14", name: "ผงหมักทอดนุ่มปรุงรสสำเร็จรูป 650 กรัม", flavor: "ทอดนุ่ม", size: 650, emoji: "🥘", unit: "ซอง", price: 249, cost: 56.57 },
  { code: "P15", name: "ผงหมักไก่ย่างวิเชียรบุรี 30 กรัม", flavor: "วิเชียร", size: 30, emoji: "🌿", unit: "ซอง", price: 19, cost: 9.23 },
  { code: "P16", name: "ผงหมักไก่ย่างวิเชียรบุรีปรุงรสสำเร็จรูป 60 กรัม", flavor: "วิเชียร", size: 60, emoji: "🌿", unit: "ซอง", price: 39, cost: 3.96 },
  { code: "P17", name: "ผงหมักไก่ย่างวิเชียรบุรีปรุงรสสำเร็จรูป 100 กรัม", flavor: "วิเชียร", size: 100, emoji: "🌿", unit: "ซอง", price: 49, cost: 7.41 },
  { code: "P18", name: "ผงหมักไก่ย่างวิเชียรบุรีปรุงรสสำเร็จรูป 650 กรัม", flavor: "วิเชียร", size: 650, emoji: "🌿", unit: "ซอง", price: 249, cost: 15.06 },
  { code: "P19", name: "ผงหมักหม่าล่า 30 กรัม", flavor: "หม่าล่า", size: 30, emoji: "🌶️", unit: "ซอง", price: 19, cost: 9.74 },
  { code: "P20", name: "ผงหมักหม่าล่าปรุงรสสำเร็จรูป 60 กรัม", flavor: "หม่าล่า", size: 60, emoji: "🌶️", unit: "ซอง", price: 39, cost: 4.11 },
  { code: "P21", name: "ผงหมักทอดเจียงฮาย 30 กรัม", flavor: "เจียงฮาย", size: 30, emoji: "🌶", unit: "ซอง", price: 19, cost: 0.00 },
  { code: "P22", name: "ผงหมักทอดเจียงฮายปรุงรสสำเร็จรูป 60 กรัม", flavor: "เจียงฮาย", size: 60, emoji: "🌶", unit: "ซอง", price: 39, cost: 0.00 },
  { code: "P23", name: "ผงหมักหมูปิ้งปรุงรสสำเร็จรูป 60 กรัม", flavor: "หมูปิ้ง", size: 60, emoji: "🍢", unit: "ซอง", price: 39, cost: 5.42 },
  { code: "P24", name: "ผงหมักหมูปิ้งปรุงรสสำเร็จรูป 650 กรัม", flavor: "หมูปิ้ง", size: 650, emoji: "🍢", unit: "ซอง", price: 249, cost: 20.92 },
  { code: "P25", name: "ผงหมักแดดเดียว 30 กรัม", flavor: "แดดเดียว", size: 30, emoji: "☀️", unit: "ซอง", price: 19, cost: 9.67 },
  { code: "P26", name: "ผงหมักแดดเดียว 60 กรัม", flavor: "แดดเดียว", size: 60, emoji: "☀️", unit: "ซอง", price: 39, cost: 8.97 },
  { code: "P27", name: "ผงหมักแดดเดียว 100 กรัม", flavor: "แดดเดียว", size: 100, emoji: "☀️", unit: "ซอง", price: 49, cost: 4.25 },
  { code: "P28", name: "ผงหมักไก่ย่างแดง 18 กรัม", flavor: "แดง", size: 18, emoji: "🍗", unit: "ซอง", price: 12, cost: 1.23 },
  { code: "P29", name: "ผงหมักหมูปิ้ง 30 กรัม", flavor: "หมูปิ้ง", size: 30, emoji: "🍢", unit: "ซอง", price: 19, cost: 2.45 },
  { code: "P30", name: "ผงหมักเข่งไก่ 60 กรัม", flavor: "เข่งไก่", size: 60, emoji: "🥘", unit: "ซอง", price: 29, cost: 3.15 },
  { code: "P31", name: "กล่องน้ำตาล 0", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457852" },
  { code: "P32", name: "กล่องน้ำตาล A", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88591546457851" },
  { code: "P33", name: "กล่องน้ำตาล AA", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457848" },
  { code: "P34", name: "กล่องน้ำตาล AB", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457849" },
  { code: "P35", name: "กล่องน้ำตาล B", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457850" },
  { code: "P36", name: "กล่องน้ำตาล 2B", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457867" },
  { code: "P37", name: "กล่องน้ำตาล C", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "886915464578689" },
  { code: "P38", name: "กล่องน้ำตาล D", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "8869154457870" },
  { code: "P39", name: "กล่องน้ำตาล E", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457871" },
  { code: "P40", name: "กล่องน้ำตาล M", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457872" },
  { code: "P41", name: "กล่องน้ำตาล M+", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457847" },
  { code: "P42", name: "กล่องน้ำตาล D-7", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "886915464578723" },
  { code: "P43", name: "กล่อง Inner Box 30 กรัม", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457840" },
  { code: "P44", name: "กล่อง Inner Box 60 กรัม", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457841" },
  { code: "P45", name: "กล่อง Inner Box 100 กรัม", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457842" },
  { code: "P46", name: "กล่องลูกฟูกสีขาวไก่แดง 100g.", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "28857129305020" },
  { code: "P47", name: "กล่องลูกฟูกสีขาวทอดนุ่ม 100g", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "28857129305037" },
  { code: "P48", name: "กล่องลูกฟูกสีขาวหาดใหญ่ 100g", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "28857129305495" },
  { code: "P49", name: "ถุงแพ็คเซลล์ 10*15", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "54484150034" },
  { code: "P50", name: "ถุงแพ็คเซลล์ 11*15", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "1050011150026" },
  { code: "P51", name: "ถุงเป่าไทยฟู้ดส์ 25 Kg.", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ใบ", price: 0, cost: 0, barcode: "88691546457837" },
  { code: "P52", name: "บับเบิ้ล", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ม้วน", price: 0, cost: 0, barcode: "88571433138264" },
  { code: "P53", name: "เทปกาวสีแดง", flavor: "บรรจุภัณฑ์", emoji: "📦", unit: "ม้วน", price: 0, cost: 0, barcode: "88691546457923" },
];

// 🥩 วัตถุดิบ — 91 รายการจาก sheet "วัตถุดิบ" + 5 ซองพิมพ์ลาย
const RAW = [
  { code: "R01", name: "น้ำตาลทรายขาว มิตรผล", unit: "กรัม", buyUnit: "กระสอบ 25 kg", cost: 0.03, supplier: "มิตรผล/KSL", barcode: "8850001001011" },
  { code: "R02", name: "มิตรผลน้ำตาลทรายขาว 5 กก./ถุง", unit: "กรัม", buyUnit: "ถุง", cost: 0.03, supplier: "มิตรผล/KSL", barcode: "8850001001028" },
  { code: "R03", name: "น้ำตาลทรายขาว มิตรผล 1kg", unit: "กรัม", buyUnit: "กิโลกรัม", cost: 0.03, supplier: "มิตรผล/KSL", barcode: "8850001001035" },
  { code: "R04", name: "น้ำตาลทรายขาว วังขนาย", unit: "กรัม", buyUnit: "กระสอบ 25 kg", cost: 0.027, supplier: "น้ำตาลวังขนาย", barcode: "8850001001042" },
  { code: "R05", name: "น้ำตาลทรายขาว KSL", unit: "กรัม", buyUnit: "กระสอบ 25 kg", cost: 0.03, supplier: "มิตรผล/KSL", barcode: "8850001001059" },
  { code: "R06", name: "น้ำตาลทรายขาว วังขนาย 1kg", unit: "กรัม", buyUnit: "กิโลกรัม", cost: 0.03, supplier: "น้ำตาลวังขนาย", barcode: "8850001001066" },
  { code: "R07", name: "น้ำตาลทรายขาว KSL 1kg", unit: "กรัม", buyUnit: "กิโลกรัม", cost: 0.03, supplier: "มิตรผล/KSL", barcode: "88500020010079" },
  { code: "R08", name: "น้ำตาลทรายแดงวังขนาย", unit: "กรัม", buyUnit: "กระสอบ 25 โล", cost: 0.03, supplier: "น้ำตาลวังขนาย", barcode: "88500020010088" },
  { code: "R09", name: "น้ำตาลทรายแดงมิตรผล", unit: "กรัม", buyUnit: "กระสอบ25โล", cost: 0.03, supplier: "มิตรผล/KSL", barcode: "88500020010097" },
  { code: "R10", name: "เกลือ ปรุงทิพย์ 0.5", unit: "กรัม", buyUnit: "500 กรัม/6*8ห่อ", cost: 0.013, supplier: "ปรุงทิพย์", barcode: "88500020010104" },
  { code: "R11", name: "เกลือ ปรุงทิพย์ 1", unit: "กรัม", buyUnit: "1 kg*24/ลัง", cost: 0.013, supplier: "ปรุงทิพย์", barcode: "88500020010113" },
  { code: "R12", name: "เกลือ ปรุงทิพย์ 5", unit: "กรัม", buyUnit: "5 kg", cost: 0.013, supplier: "ปรุงทิพย์", barcode: "88500020010122" },
  { code: "R13", name: "เกลือ ดอกเกลือ", unit: "กรัม", buyUnit: "ซอง", cost: 0.013, supplier: "ตลาดสด", barcode: "88500020010131" },
  { code: "R14", name: "เกลือสมุทร เกลือแกง", unit: "กรัม", buyUnit: "กระสอบ 30 กิโลกรัม", cost: 0.013, supplier: "ตลาดสด", barcode: "88500020010140" },
  { code: "R15", name: "เกลือเปียก เกลือถุง", unit: "กรัม", buyUnit: "หิ้วละ 9 ถุง", cost: 0.013, supplier: "ตลาดสด", barcode: "88500020010159" },
  { code: "R16", name: "ผงชูรส อายินัว", unit: "กรัม", buyUnit: "ลัง", cost: 0.1, supplier: "อายิโนะโมะโต๊ะ", barcode: "88500020010168" },
  { code: "R17", name: "ผงชูรส I + G", unit: "กรัม", buyUnit: "โล", cost: 0.0388, supplier: "ตลาดสด", barcode: "88500020010177" },
  { code: "R18", name: "ผงชูรส อายิออริจินัล", unit: "กรัม", buyUnit: "ลัง 3Kg X 8 ถุง", cost: 0.1, supplier: "อายิโนะโมะโต๊ะ", barcode: "88500020010186" },
  { code: "R19", name: "ชูรส อายิ 3 kg ถุง", unit: "กรัม", buyUnit: "ถุุง/3kg", cost: 0.1, supplier: "อายิโนะโมะโต๊ะ", barcode: "88500020010195" },
  { code: "R20", name: "ซอสหอยนางรม แบบผง", unit: "กรัม", buyUnit: "ลัง", cost: 0.05, supplier: "ตลาดสด", barcode: "88500020010202" },
  { code: "R21", name: "ซอสปรุงรส ฝาเขียวแบบผง", unit: "กรัม", buyUnit: "ซอง", cost: 0.05, supplier: "ตลาดสด", barcode: "88500020010211" },
  { code: "R22", name: "แป้งข้าวเจ้า ARO ลัง", unit: "กรัม", buyUnit: "ลัง/1000g*10ถุง", cost: 0.035, supplier: "Makro", barcode: "88500020010220" },
  { code: "R23", name: "แป้งข้าวเจ้า ARO 1 กิโลกรัม", unit: "กรัม", buyUnit: "ถุง", cost: 0.033, supplier: "Makro", barcode: "88500020010239" },
  { code: "R24", name: "แป้งข้าวเจ้าใบหยก", unit: "กรัม", buyUnit: "ถุุง", cost: 0.035, supplier: "สามเศียร/ใบหยก", barcode: "88500020010248" },
  { code: "R25", name: "แป้งข้าวเจ้า สามเศียร", unit: "กรัม", buyUnit: "ซอง", cost: 0.035, supplier: "สามเศียร/ใบหยก", barcode: "88500020010257" },
  { code: "R26", name: "แป้งข้าวเจ้า อื่นๆ", unit: "กรัม", buyUnit: "ซอง", cost: 0.035, supplier: "ตลาดสด", barcode: "88500020010266" },
  { code: "R27", name: "แป้งมัน ARO 1kg", unit: "กรัม", buyUnit: "ถุง 1 kg", cost: 0.034, supplier: "Makro", barcode: "88500020010275" },
  { code: "R28", name: "แป้งมัน ARO", unit: "กรัม", buyUnit: "ลัง/1000g*10ถุง", cost: 0.035, supplier: "Makro", barcode: "88500020010284" },
  { code: "R29", name: "แป้งมัน สามเศียร", unit: "กรัม", buyUnit: "ซอง", cost: 0.035, supplier: "สามเศียร/ใบหยก", barcode: "88500020010293" },
  { code: "R30", name: "แป้งมัน อื่นๆ", unit: "กรัม", buyUnit: "ซอง", cost: 0.035, supplier: "ตลาดสด", barcode: "88500020010300" },
  { code: "R31", name: "แป้งข้าวโพด ARO 1 kg", unit: "กรัม", buyUnit: "ถุง 1 kg", cost: 0.038, supplier: "Makro", barcode: "88500020010319" },
  { code: "R32", name: "แป้งข้าวโพด ARO ลัง", unit: "กรัม", buyUnit: "ลัง/1000g*10ถุง", cost: 0.035, supplier: "Makro", barcode: "88500020010328" },
  { code: "R33", name: "แป้งข้าวโพด Super 1kg", unit: "กรัม", buyUnit: "ซอง 1kg", cost: 0.035, supplier: "ตลาดสด", barcode: "88500020010337" },
  { code: "R34", name: "แป้งข้าวโพด อื่นๆ", unit: "กรัม", buyUnit: "ซอง", cost: 0.035, supplier: "ตลาดสด", barcode: "88500020010346" },
  { code: "R35", name: "แป้งโกกิ", unit: "กรัม", buyUnit: "ถุง 500g X 3ถุง", cost: 0.23, supplier: "ตลาดสด", barcode: "88500020010355" },
  { code: "R36", name: "แป้งทอดกรอบ 1 kg", unit: "กรัม", buyUnit: "ซอง 1kg", cost: 0.037, supplier: "ตลาดสด", barcode: "88500020010364" },
  { code: "R37", name: "พริกไทยดำ กุยลิ้มฮึ้ง", unit: "กรัม", buyUnit: "ซอง", cost: 0.09, supplier: "กุยลิ้มฮึ้ง", barcode: "88500020010373" },
  { code: "R38", name: "พริกไทยดำ SAO การเกษตร", unit: "กรัม", buyUnit: "กระสอบ 25 kg", cost: 0.09, supplier: "SAO การเกษตร", barcode: "88500020010382" },
  { code: "R39", name: "พริกไทยดำ ARO", unit: "กรัม", buyUnit: "ซอง 500 กรัม", cost: 0.09, supplier: "Makro", barcode: "88500020010391" },
  { code: "R40", name: "เม็ดผักชี กุยลิ้มฮึ้ง", unit: "กรัม", buyUnit: "กระสอบ 25 kg", cost: 0.055, supplier: "กุยลิ้มฮึ้ง", barcode: "88500020010408" },
  { code: "R41", name: "พริกไทยขาว กุยลิ้มฮึ้ง", unit: "กรัม", buyUnit: "ซอง", cost: 0.09, supplier: "กุยลิ้มฮึ้ง", barcode: "88500020010417" },
  { code: "R42", name: "พริกไทยขาว SAO การเกษตร", unit: "กรัม", buyUnit: "ซอง", cost: 0.09, supplier: "SAO การเกษตร", barcode: "88500020010426" },
  { code: "R43", name: "พริกไทยขาว ARO", unit: "กรัม", buyUnit: "ซอง    500 g", cost: 0.09, supplier: "Makro", barcode: "88500020010435" },
  { code: "R44", name: "เม็ดผักชี SAO การเกษตร", unit: "กรัม", buyUnit: "ซอง", cost: 0.2, supplier: "SAO การเกษตร", barcode: "88500020010444" },
  { code: "R45", name: "เม็ดผักชี ARO", unit: "กรัม", buyUnit: "ซอง", cost: 0.2, supplier: "Makro", barcode: "88500020010453" },
  { code: "R46", name: "ยี่หร่า กุยลิ้มฮึ้ง", unit: "กรัม", buyUnit: "ซอง/1kg", cost: 0.2, supplier: "กุยลิ้มฮึ้ง", barcode: "88500020010462" },
  { code: "R47", name: "ยี่หร่า SAO การเกษตร", unit: "กรัม", buyUnit: "ซอง", cost: 0.2, supplier: "SAO การเกษตร", barcode: "88500020010471" },
  { code: "R48", name: "ยี่หร่า ARO", unit: "กรัม", buyUnit: "ซอง/1kg", cost: 0.356, supplier: "Makro", barcode: "88500020010480" },
  { code: "R49", name: "หอมแดง คำธารา ลัง 4 kg", unit: "กรัม", buyUnit: "ลัง 4 Kg", cost: 0.06, supplier: "คำธารา", barcode: "88500020010499" },
  { code: "R50", name: "หอมแดง คำธารา ลัังใหญ่", unit: "กรัม", buyUnit: "ลังใหญ่/ 6 kg", cost: 0.06, supplier: "คำธารา", barcode: "88500020010505" },
  { code: "R51", name: "พริกหม่าล่าแม่น้อย", unit: "กรัม", buyUnit: "ถุง 250 กรัม", cost: 0.15, supplier: "แม่น้อย", barcode: "88500020010514" },
  { code: "R52", name: "พริกหม่าล่า ARO", unit: "กรัม", buyUnit: "ซอง 500 กรัม", cost: 0.15, supplier: "Makro", barcode: "88500020010523" },
  { code: "R53", name: "หมาล่า", unit: "กรัม", buyUnit: "ซอง", cost: 0.5, supplier: "ตลาดสด", barcode: "88500020010532" },
  { code: "R54", name: "พริก", unit: "กรัม", buyUnit: "ซอง", cost: 0.15, supplier: "ตลาดสด", barcode: "88500020010541" },
  { code: "R55", name: "ฮาวา เขียว", unit: "กรัม", buyUnit: "ซอง 200 กรัม", cost: 0.53, supplier: "ตลาดสด", barcode: "88500020010550" },
  { code: "R56", name: "ฮาวา แดง", unit: "กรัม", buyUnit: "ซอง 200 กรัม", cost: 0.53, supplier: "ตลาดสด", barcode: "88500020010569" },
  { code: "R57", name: "กระเทียม", unit: "กรัม", buyUnit: "ซอง", cost: 0.06, supplier: "ตลาดสด", barcode: "88500020010578" },
  { code: "R58", name: "เบนลี่", unit: "กรัม", buyUnit: "ลัง", cost: 0.1, supplier: "ตลาดสด", barcode: "88500020010587" },
  { code: "R59", name: "ตะไคร้ SAO การเกษตร", unit: "กรัม", buyUnit: "ซอง", cost: 0.06, supplier: "SAO การเกษตร", barcode: "88500020010596" },
  { code: "R60", name: "ตะไคร้", unit: "กรัม", buyUnit: "ลัง/8 Kg", cost: 0.06, supplier: "ตลาดสด", barcode: "88500020010603" },
  { code: "R61", name: "ปาปริก้า Yummy เจริญวัย", unit: "กรัม", buyUnit: "ลัง 20 kg", cost: 0.22, supplier: "Makro", barcode: "88500020010612" },
  { code: "R62", name: "ปาปริก้า Yummy Mckro", unit: "กรัม", buyUnit: "ซอง/500g", cost: 0.218, supplier: "Makro", barcode: "88500020010621" },
  { code: "R63", name: "วิ้งแซ่บ ผึ้งหลวง", unit: "กรัม", buyUnit: "ซอง/500กรัม", cost: 0.45, supplier: "ผึ้งหลวง", barcode: "88500020010630" },
  { code: "R64", name: "บาบีคิว ผึ้งหลวง", unit: "กรัม", buyUnit: "ซอง/500กรัม", cost: 0.45, supplier: "ผึ้งหลวง", barcode: "88500020010649" },
  { code: "R65", name: "ฮอตแอนสไปซี่  ผึ้งหลวง", unit: "กรัม", buyUnit: "ซอง/500กรัม", cost: 0.45, supplier: "ผึ้งหลวง", barcode: "88500020010658" },
  { code: "R66", name: "ชีท ผึ้งหลวง", unit: "กรัม", buyUnit: "ซอง/500กรัม", cost: 0.45, supplier: "ผึ้งหลวง", barcode: "88500020010667" },
  { code: "R67", name: "เพิ่มน้ำหนัก", unit: "กรัม", buyUnit: "ซอง", cost: 0.1, supplier: "ตลาดสด", barcode: "88500020010676" },
  { code: "R68", name: "สีส้มแดง อดินพ", unit: "กรัม", buyUnit: "ถังละ 25 โล", cost: 0.35, supplier: "อดินพ ทรัพย์อุดม", barcode: "88500020010685" },
  { code: "R69", name: "สีส้ม อดินพ ทรัพย์อุดม", unit: "กรัม", buyUnit: "1ลัง/50 กล่อง", cost: 0.35, supplier: "อดินพ ทรัพย์อุดม", barcode: "88500020010694" },
  { code: "R70", name: "สีเหลืองไข่", unit: "กรัม", buyUnit: "ถังละ 25 โล", cost: 0.35, supplier: "ตลาดสด", barcode: "88500020010701" },
  { code: "R71", name: "รสดีหมู Mckro", unit: "กรัม", buyUnit: "1.5 x 8ถุง", cost: 0.1, supplier: "Makro", barcode: "88500020010710" },
  { code: "R72", name: "รสดีหมู เซลล์", unit: "กรัม", buyUnit: "1 ลัง/8 ซอง", cost: 0.1, supplier: "ตัวแทนจำหน่าย", barcode: "88500020010729" },
  { code: "R73", name: "รสดีเห็ดหอม Mckro", unit: "กรัม", buyUnit: "ซอง 380 กรัม", cost: 0.1, supplier: "Makro", barcode: "88500020010738" },
  { code: "R74", name: "เติมทิพย์ Mckro", unit: "กรัม", buyUnit: "ซอง 800 g", cost: 0.1025, supplier: "Makro", barcode: "88500020010747" },
  { code: "R75", name: "เติมทิพย์ เซลล์", unit: "กรัม", buyUnit: "ถุง", cost: 0.1, supplier: "ตัวแทนจำหน่าย", barcode: "88500020010756" },
  { code: "R76", name: "ฟ้าไทย รสไก่ 1 ถุง 800 กรัม", unit: "กรัม", buyUnit: "ซอง/800 g", cost: 0.1, supplier: "ฟ้าไทย", barcode: "88500020010765" },
  { code: "R77", name: "ฟ้าไทย", unit: "กรัม", buyUnit: "ลัง/800*10ถุง", cost: 0.1, supplier: "ฟ้าไทย", barcode: "88500020010774" },
  { code: "R78", name: "ผงผัดทิพรส", unit: "กรัม", buyUnit: "ลัง", cost: 0.1, supplier: "ตลาดสด", barcode: "88500020010783" },
  { code: "R79", name: "พริกหม่าล่า ARO", unit: "กรัม", buyUnit: "ซอง 200 กรัม", cost: 0.15, supplier: "Makro", barcode: "88500020010792" },
  { code: "R80", name: "ชวงเจียป่น", unit: "กรัม", buyUnit: "ซอง 200 กรัม", cost: 0.1, supplier: "ตลาดสด", barcode: "88500020010809" },
  { code: "R81", name: "แบกกิ้งโซดา", unit: "กรัม", buyUnit: "ถุง 1 kg", cost: 0.05, supplier: "ตลาดสด", barcode: "88500020010818" },
  { code: "R82", name: "ปลาร้า", unit: "กรัม", buyUnit: "ลัง 30 ขวด", cost: 0.04, supplier: "ตลาดสด", barcode: "88500020010827" },
  { code: "R83", name: "ผงน้ำตาลเพื่อสุขภาพ Erythitol", unit: "กรัม", buyUnit: "กระสอบ 25 kg", cost: 0.03, supplier: "นำเข้า", barcode: "88500020010836" },
  { code: "R84", name: "ตะไคร้้บด 5 Kg", unit: "กรัม", buyUnit: "กิโลกรัม", cost: 0.06, supplier: "ตลาดสด", barcode: "88500020010845" },
  { code: "R85", name: "ตะไคร้้บด 1 Kg", unit: "กรัม", buyUnit: "กิโลกรัม", cost: 0.06, supplier: "ตลาดสด", barcode: "88500020010854" },
  { code: "R86", name: "ตะไคร้้บด 2 Kg", unit: "กรัม", buyUnit: "กิโลกรัม", cost: 0.06, supplier: "ตลาดสด", barcode: "88500020010863" },
  { code: "R87", name: "ผงมะกูด", unit: "กรัม", buyUnit: "ลัง/5kg", cost: 0.16, supplier: "ตลาดสด", barcode: "88500020010872" },
  { code: "R88", name: "ผงขมิ้น เอโร่ 250 กรัม", unit: "กรัม", buyUnit: "ซอง 250 g", cost: 0.16, supplier: "ตลาดสด", barcode: "88500020010881" },
  { code: "R89", name: "ผงขมิ้น ศิริเรืองอำไพ 1000 g", unit: "กรัม", buyUnit: "ซอง 1 Kg", cost: 0.16, supplier: "ศิริเรืองอำไพ", barcode: "88500020010890" },
  { code: "R90", name: "ผงขมิ้น สีเข้ม 10 Kg", unit: "กรัม", buyUnit: "ซอง 10 Kg", cost: 0.35, supplier: "ตลาดสด", barcode: "88500020010907" },
  { code: "R91", name: "ซอสถั่วเหลือง", unit: "กรัม", buyUnit: "ลัง/24 Kg", cost: 0.05, supplier: "ตลาดสด", barcode: "88500020010916" },
  { code: "PK30",   name: "ซองพิมพ์ลาย 30 ก.", unit: "ใบ", buyUnit: "ใบ", cost: 1.2, supplier: "บรรจุภัณฑ์เพื่อนแท้", barcode: "88500020010925" },
  { code: "PK60",   name: "ซองพิมพ์ลาย 60 ก.", unit: "ใบ", buyUnit: "ใบ", cost: 1.8, supplier: "บรรจุภัณฑ์เพื่อนแท้", barcode: "88500020010934" },
  { code: "PK100",  name: "ซองพิมพ์ลาย 100 ก.", unit: "ใบ", buyUnit: "ใบ", cost: 2.4, supplier: "บรรจุภัณฑ์เพื่อนแท้", barcode: "88500020010943" },
  { code: "PK650",  name: "ซองพิมพ์ลาย 650 ก.", unit: "ใบ", buyUnit: "ใบ", cost: 5.5, supplier: "บรรจุภัณฑ์เพื่อนแท้", barcode: "88500020010952" },
  { code: "PK1000", name: "ซองพิมพ์ลาย 1000 ก.", unit: "ใบ", buyUnit: "ใบ", cost: 8.2, supplier: "บรรจุภัณฑ์เพื่อนแท้", barcode: "88500020010961" },
];

// 🧮 สูตร — ต่อ 1 ซอง (กรัม)
const RECIPES = [
  { code: "S01", name: "สูตร ผงหมักไก่ย่างแดง 30 กรัม", product: "P01", makes: "1 ซอง", items: [
    { raw: "R04", qty: 20.832 },
    { raw: "R11", qty: 4.791 },
    { raw: "R19", qty: 1.875 },
    { raw: "R74", qty: 1.668 },
    { raw: "R17", qty: 0.417 },
    { raw: "R70", qty: 0.417 },
    { raw: "PK30", qty: 1 },
  ]},
  { code: "S02", name: "สูตร ผงหมักไก่ย่างแดงปรุงรสสำเร็จรูป 60 กรัม", product: "P02", makes: "1 ซอง", items: [
    { raw: "R04", qty: 41.664 },
    { raw: "R11", qty: 9.582 },
    { raw: "R19", qty: 3.75 },
    { raw: "R74", qty: 3.336 },
    { raw: "R17", qty: 0.834 },
    { raw: "R70", qty: 0.834 },
    { raw: "PK60", qty: 1 },
  ]},
  { code: "S03", name: "สูตร ผงหมักไก่ย่างแดงปรุงรสสำเร็จรูป 100 กรัม", product: "P03", makes: "1 ซอง", items: [
    { raw: "R04", qty: 69.44 },
    { raw: "R11", qty: 15.97 },
    { raw: "R19", qty: 6.25 },
    { raw: "R74", qty: 5.56 },
    { raw: "R17", qty: 1.39 },
    { raw: "R70", qty: 1.39 },
    { raw: "PK100", qty: 1 },
  ]},
  { code: "S04", name: "สูตร ผงหมักไก่ย่างแดงปรุงรสสำเร็จรูป 650 กรัม", product: "P04", makes: "1 ซอง", items: [
    { raw: "R04", qty: 451.36 },
    { raw: "R11", qty: 103.805 },
    { raw: "R19", qty: 40.625 },
    { raw: "R74", qty: 36.14 },
    { raw: "R17", qty: 9.035 },
    { raw: "R70", qty: 9.035 },
    { raw: "PK650", qty: 1 },
  ]},
  { code: "S05", name: "สูตร ผงหมักไก่ย่างแดงปรุงรสสำเร็จรูป 1000 กรัม", product: "P05", makes: "1 ซอง", items: [
    { raw: "R04", qty: 694.4 },
    { raw: "R11", qty: 159.7 },
    { raw: "R19", qty: 62.5 },
    { raw: "R74", qty: 55.6 },
    { raw: "R17", qty: 13.9 },
    { raw: "R70", qty: 13.9 },
    { raw: "PK1000", qty: 1 },
  ]},
  { code: "S06", name: "สูตร ผงหมักไก่ทอดหาดใหญ่ 30 กรัม", product: "P06", makes: "1 ซอง", items: [
    { raw: "R04", qty: 2.397 },
    { raw: "R11", qty: 2.739 },
    { raw: "R19", qty: 2.568 },
    { raw: "R74", qty: 1.713 },
    { raw: "R17", qty: 0.57 },
    { raw: "R23", qty: 13.695 },
    { raw: "R38", qty: 1.14 },
    { raw: "R45", qty: 0.57 },
    { raw: "R48", qty: 0.57 },
    { raw: "R49", qty: 1.14 },
    { raw: "R62", qty: 2.853 },
    { raw: "R68", qty: 0.042 },
    { raw: "PK30", qty: 1 },
  ]},
  { code: "S07", name: "สูตร ผงหมักไก่ทอดหาดใหญ่ปรุงรสสำเร็จรูป 60 กรัม", product: "P07", makes: "1 ซอง", items: [
    { raw: "R04", qty: 4.794 },
    { raw: "R11", qty: 5.478 },
    { raw: "R19", qty: 5.136 },
    { raw: "R74", qty: 3.426 },
    { raw: "R17", qty: 1.14 },
    { raw: "R23", qty: 27.39 },
    { raw: "R38", qty: 2.28 },
    { raw: "R45", qty: 1.14 },
    { raw: "R48", qty: 1.14 },
    { raw: "R49", qty: 2.28 },
    { raw: "R62", qty: 5.706 },
    { raw: "R68", qty: 0.084 },
    { raw: "PK60", qty: 1 },
  ]},
  { code: "S08", name: "สูตร ผงหมักไก่ทอดหาดใหญ่ปรุงรสสำเร็จรูป 100 กรัม", product: "P08", makes: "1 ซอง", items: [
    { raw: "R04", qty: 7.99 },
    { raw: "R11", qty: 9.13 },
    { raw: "R19", qty: 8.56 },
    { raw: "R74", qty: 5.71 },
    { raw: "R17", qty: 1.9 },
    { raw: "R23", qty: 45.65 },
    { raw: "R38", qty: 3.8 },
    { raw: "R45", qty: 1.9 },
    { raw: "R48", qty: 1.9 },
    { raw: "R49", qty: 3.8 },
    { raw: "R62", qty: 9.51 },
    { raw: "R68", qty: 0.14 },
    { raw: "PK100", qty: 1 },
  ]},
  { code: "S09", name: "สูตร ผงหมักไก่ทอดหาดใหญ่ปรุงรสสำเร็จรูป 650 กรัม", product: "P09", makes: "1 ซอง", items: [
    { raw: "R04", qty: 51.935 },
    { raw: "R11", qty: 59.345 },
    { raw: "R19", qty: 55.64 },
    { raw: "R74", qty: 37.115 },
    { raw: "R17", qty: 12.35 },
    { raw: "R23", qty: 296.725 },
    { raw: "R38", qty: 24.7 },
    { raw: "R45", qty: 12.35 },
    { raw: "R48", qty: 12.35 },
    { raw: "R49", qty: 24.7 },
    { raw: "R62", qty: 61.815 },
    { raw: "R68", qty: 0.91 },
    { raw: "PK650", qty: 1 },
  ]},
  { code: "S10", name: "สูตร ผงหมักไก่ทอดหาดใหญ่ปรุงรสสำเร็จรูป 1000 กรัม", product: "P10", makes: "1 ซอง", items: [
    { raw: "R04", qty: 79.9 },
    { raw: "R11", qty: 91.3 },
    { raw: "R19", qty: 85.6 },
    { raw: "R74", qty: 57.1 },
    { raw: "R17", qty: 19 },
    { raw: "R23", qty: 456.5 },
    { raw: "R38", qty: 38 },
    { raw: "R45", qty: 19 },
    { raw: "R48", qty: 19 },
    { raw: "R49", qty: 38 },
    { raw: "R62", qty: 95.1 },
    { raw: "R68", qty: 1.4 },
    { raw: "PK1000", qty: 1 },
  ]},
  { code: "S11", name: "สูตร ผงหมักทอดนุ่ม 30 กรัม", product: "P11", makes: "1 ซอง", items: [
    { raw: "R04", qty: 16.959 },
    { raw: "R11", qty: 4.071 },
    { raw: "R19", qty: 1.527 },
    { raw: "R74", qty: 1.527 },
    { raw: "R17", qty: 0.339 },
    { raw: "R27", qty: 1.695 },
    { raw: "R31", qty: 1.695 },
    { raw: "R81", qty: 1.938 },
    { raw: "R68", qty: 0.123 },
    { raw: "R70", qty: 0.123 },
    { raw: "PK30", qty: 1 },
  ]},
  { code: "S12", name: "สูตร ผงหมักทอดนุ่มปรุงรสสำเร็จรูป 60 กรัม", product: "P12", makes: "1 ซอง", items: [
    { raw: "R04", qty: 33.918 },
    { raw: "R11", qty: 8.142 },
    { raw: "R19", qty: 3.054 },
    { raw: "R74", qty: 3.054 },
    { raw: "R17", qty: 0.678 },
    { raw: "R27", qty: 3.39 },
    { raw: "R31", qty: 3.39 },
    { raw: "R81", qty: 3.876 },
    { raw: "R68", qty: 0.246 },
    { raw: "R70", qty: 0.246 },
    { raw: "PK60", qty: 1 },
  ]},
  { code: "S13", name: "สูตร ผงหมักทอดนุ่มปรุงรสสำเร็จรูป 100 กรัม", product: "P13", makes: "1 ซอง", items: [
    { raw: "R04", qty: 56.53 },
    { raw: "R11", qty: 13.57 },
    { raw: "R19", qty: 5.09 },
    { raw: "R74", qty: 5.09 },
    { raw: "R17", qty: 1.13 },
    { raw: "R27", qty: 5.65 },
    { raw: "R31", qty: 5.65 },
    { raw: "R81", qty: 6.46 },
    { raw: "R68", qty: 0.41 },
    { raw: "R70", qty: 0.41 },
    { raw: "PK100", qty: 1 },
  ]},
  { code: "S14", name: "สูตร ผงหมักทอดนุ่มปรุงรสสำเร็จรูป 650 กรัม", product: "P14", makes: "1 ซอง", items: [
    { raw: "R04", qty: 367.445 },
    { raw: "R11", qty: 88.205 },
    { raw: "R19", qty: 33.085 },
    { raw: "R74", qty: 33.085 },
    { raw: "R17", qty: 7.345 },
    { raw: "R27", qty: 36.725 },
    { raw: "R31", qty: 36.725 },
    { raw: "R81", qty: 41.99 },
    { raw: "R68", qty: 2.665 },
    { raw: "R70", qty: 2.665 },
    { raw: "PK650", qty: 1 },
  ]},
  { code: "S15", name: "สูตร ผงหมักไก่ย่างวิเชียรบุรี 30 กรัม", product: "P15", makes: "1 ซอง", items: [
    { raw: "R04", qty: 11.286 },
    { raw: "R11", qty: 6.021 },
    { raw: "R19", qty: 3.762 },
    { raw: "R74", qty: 3.762 },
    { raw: "R20", qty: 2.823 },
    { raw: "R39", qty: 0.942 },
    { raw: "R89", qty: 0.375 },
    { raw: "R86", qty: 0.942 },
    { raw: "R70", qty: 0.09 },
    { raw: "PK30", qty: 1 },
  ]},
  { code: "S16", name: "สูตร ผงหมักไก่ย่างวิเชียรบุรีปรุงรสสำเร็จรูป 60 กรัม", product: "P16", makes: "1 ซอง", items: [
    { raw: "R04", qty: 22.572 },
    { raw: "R11", qty: 12.042 },
    { raw: "R19", qty: 7.524 },
    { raw: "R74", qty: 7.524 },
    { raw: "R20", qty: 5.646 },
    { raw: "R39", qty: 1.884 },
    { raw: "R89", qty: 0.75 },
    { raw: "R86", qty: 1.884 },
    { raw: "R70", qty: 0.18 },
    { raw: "PK60", qty: 1 },
  ]},
  { code: "S17", name: "สูตร ผงหมักไก่ย่างวิเชียรบุรีปรุงรสสำเร็จรูป 100 กรัม", product: "P17", makes: "1 ซอง", items: [
    { raw: "R04", qty: 37.62 },
    { raw: "R11", qty: 20.07 },
    { raw: "R19", qty: 12.54 },
    { raw: "R74", qty: 12.54 },
    { raw: "R20", qty: 9.41 },
    { raw: "R39", qty: 3.14 },
    { raw: "R89", qty: 1.25 },
    { raw: "R86", qty: 3.14 },
    { raw: "R70", qty: 0.3 },
    { raw: "PK100", qty: 1 },
  ]},
  { code: "S18", name: "สูตร ผงหมักไก่ย่างวิเชียรบุรีปรุงรสสำเร็จรูป 650 กรัม", product: "P18", makes: "1 ซอง", items: [
    { raw: "R04", qty: 244.53 },
    { raw: "R11", qty: 130.455 },
    { raw: "R19", qty: 81.51 },
    { raw: "R74", qty: 81.51 },
    { raw: "R20", qty: 61.165 },
    { raw: "R39", qty: 20.41 },
    { raw: "R89", qty: 8.125 },
    { raw: "R86", qty: 20.41 },
    { raw: "R70", qty: 1.95 },
    { raw: "PK650", qty: 1 },
  ]},
  { code: "S19", name: "สูตร ผงหมักหม่าล่า 30 กรัม", product: "P19", makes: "1 ซอง", items: [
    { raw: "R04", qty: 14.2857 },
    { raw: "R11", qty: 3.5715 },
    { raw: "R19", qty: 2.1429 },
    { raw: "R74", qty: 1.1904 },
    { raw: "R17", qty: 0.4761 },
    { raw: "R20", qty: 2.3811 },
    { raw: "R27", qty: 0.5952 },
    { raw: "R31", qty: 0.5952 },
    { raw: "R53", qty: 1.9047 },
    { raw: "R54", qty: 1.9047 },
    { raw: "R56", qty: 0.4761 },
    { raw: "R80", qty: 0.4761 },
    { raw: "PK30", qty: 1 },
  ]},
  { code: "S20", name: "สูตร ผงหมักหม่าล่าปรุงรสสำเร็จรูป 60 กรัม", product: "P20", makes: "1 ซอง", items: [
    { raw: "R04", qty: 28.5714 },
    { raw: "R11", qty: 7.143 },
    { raw: "R19", qty: 4.2858 },
    { raw: "R74", qty: 2.3808 },
    { raw: "R17", qty: 0.9522 },
    { raw: "R20", qty: 4.7622 },
    { raw: "R27", qty: 1.1904 },
    { raw: "R31", qty: 1.1904 },
    { raw: "R53", qty: 3.8094 },
    { raw: "R54", qty: 3.8094 },
    { raw: "R56", qty: 0.9522 },
    { raw: "R80", qty: 0.9522 },
    { raw: "PK60", qty: 1 },
  ]},
  { code: "S21", name: "สูตร ผงหมักทอดเจียงฮาย 30 กรัม", product: "P21", makes: "1 ซอง", items: [
    { raw: "R11", qty: 1.365 },
    { raw: "R19", qty: 1.365 },
    { raw: "R74", qty: 2.727 },
    { raw: "R23", qty: 6.819 },
    { raw: "R35", qty: 6.819 },
    { raw: "R36", qty: 6.819 },
    { raw: "R39", qty: 2.046 },
    { raw: "R62", qty: 2.046 },
    { raw: "PK30", qty: 1 },
  ]},
  { code: "S22", name: "สูตร ผงหมักทอดเจียงฮายปรุงรสสำเร็จรูป 60 กรัม", product: "P22", makes: "1 ซอง", items: [
    { raw: "R11", qty: 2.73 },
    { raw: "R19", qty: 2.73 },
    { raw: "R74", qty: 272.88 },
    { raw: "R23", qty: 13.638 },
    { raw: "R35", qty: 13.638 },
    { raw: "R36", qty: 13.638 },
    { raw: "R39", qty: 4.092 },
    { raw: "R62", qty: 4.092 },
    { raw: "PK60", qty: 1 },
  ]},
  { code: "S23", name: "สูตร ผงหมักหมูปิ้งปรุงรสสำเร็จรูป 60 กรัม", product: "P23", makes: "1 ซอง", items: [
    { raw: "R04", qty: 36.39 },
    { raw: "R11", qty: 6.822 },
    { raw: "R19", qty: 2.73 },
    { raw: "R74", qty: 2.73 },
    { raw: "R17", qty: 0.912 },
    { raw: "R20", qty: 2.226 },
    { raw: "R27", qty: 2.73 },
    { raw: "R31", qty: 2.73 },
    { raw: "R40", qty: 1.362 },
    { raw: "R81", qty: 1.362 },
    { raw: "PK60", qty: 1 },
  ]},
  { code: "S24", name: "สูตร ผงหมักหมูปิ้งปรุงรสสำเร็จรูป 650 กรัม", product: "P24", makes: "1 ซอง", items: [
    { raw: "R04", qty: 394.225 },
    { raw: "R11", qty: 73.905 },
    { raw: "R19", qty: 29.575 },
    { raw: "R74", qty: 29.575 },
    { raw: "R17", qty: 9.88 },
    { raw: "R20", qty: 24.115 },
    { raw: "R27", qty: 29.575 },
    { raw: "R31", qty: 29.575 },
    { raw: "R40", qty: 14.755 },
    { raw: "R81", qty: 14.755 },
    { raw: "PK650", qty: 1 },
  ]},
  { code: "S25", name: "สูตร ผงหมักแดดเดียว 30 กรัม", product: "P25", makes: "1 ซอง", items: [
    { raw: "R04", qty: 20.718 },
    { raw: "R11", qty: 4.971 },
    { raw: "R19", qty: 1.866 },
    { raw: "R74", qty: 1.866 },
    { raw: "R17", qty: 0.414 },
    { raw: "R68", qty: 0.084 },
    { raw: "R70", qty: 0.084 },
    { raw: "PK30", qty: 1 },
  ]},
  { code: "S26", name: "สูตร ผงหมักแดดเดียว 60 กรัม", product: "P26", makes: "1 ซอง", items: [
    { raw: "R04", qty: 41.436 },
    { raw: "R11", qty: 9.942 },
    { raw: "R19", qty: 3.732 },
    { raw: "R74", qty: 3.732 },
    { raw: "R17", qty: 0.828 },
    { raw: "R68", qty: 0.168 },
    { raw: "R70", qty: 0.168 },
    { raw: "PK60", qty: 1 },
  ]},
  { code: "S27", name: "สูตร ผงหมักแดดเดียว 100 กรัม", product: "P27", makes: "1 ซอง", items: [
    { raw: "R04", qty: 69.06 },
    { raw: "R11", qty: 16.57 },
    { raw: "R19", qty: 6.22 },
    { raw: "R74", qty: 6.22 },
    { raw: "R17", qty: 1.38 },
    { raw: "R68", qty: 0.28 },
    { raw: "R70", qty: 0.28 },
    { raw: "PK100", qty: 1 },
  ]},
  { code: "S36", name: "สูตร ผงหมักไก่ย่างแดง 100 กรัม 8 กิโลกรัม", product: "P03", makes: "1 ซอง", items: [
    { raw: "R03", qty: 72.0461 },
    { raw: "R11", qty: 16.5706 },
    { raw: "R19", qty: 6.4841 },
    { raw: "R74", qty: 5.7637 },
    { raw: "R17", qty: 1.4409 },
    { raw: "R70", qty: 1.4409 },
    { raw: "PK100", qty: 1 },
  ]},
];

// 🏭 การผลิต — ประวัติล็อต
const PRODUCTIONS = [
  {
    "date": "10 มิถุนายน",
    "code": "PD26060001",
    "recipe": "S36",
    "qty": 2776,
    "unit": "ซอง",
    "by": "ยายปู",
    "status": "done"
  },
  {
    "date": "10 มิถุนายน",
    "code": "PD26060002",
    "recipe": "S17",
    "qty": 4000,
    "unit": "ซอง",
    "by": "อั้นฯ",
    "status": "done"
  },
  {
    "date": "09 มิถุนายน",
    "code": "PD26060003",
    "recipe": "S19",
    "qty": 18000,
    "unit": "กระสอบ",
    "by": "ยายปู",
    "status": "done"
  },
  {
    "date": "08 มิถุนายน",
    "code": "PD26060004",
    "recipe": "S74",
    "qty": 16000,
    "unit": "ขวด",
    "by": "อั้นฯ",
    "status": "done"
  },
  {
    "date": "07 มิถุนายน",
    "code": "PD26060005",
    "recipe": "R03",
    "qty": 200000,
    "unit": "กิโลกรัม",
    "by": "ยายปู",
    "status": "in progress"
  }
];

// 📝 ค่าใช้จ่าย
const EXPENSES = [
  {
    "date": "18 พ.ค.",
    "category": "ค่าน้ำค่าไฟ",
    "note": "ค่าไฟโรงผลิต พ.ค.",
    "amount": 2840
  },
  {
    "date": "16 พ.ค.",
    "category": "ค่าขนส่ง",
    "note": "ส่งของไปตลาดสี่มุมเมือง",
    "amount": 380
  },
  {
    "date": "15 พ.ค.",
    "category": "ค่าจ้าง",
    "note": "ค่าจ้างพี่นิด 2 สัปดาห์",
    "amount": 4500
  },
  {
    "date": "13 พ.ค.",
    "category": "ของใช้สิ้นเปลือง",
    "note": "ถุงมือ หมวกคลุมผม ผ้ากันเปื้อน",
    "amount": 480
  },
  {
    "date": "12 พ.ค.",
    "category": "ซ่อมบำรุง",
    "note": "เครื่องชั่งดิจิตอลเสีย",
    "amount": 850
  },
  {
    "date": "10 พ.ค.",
    "category": "ค่าขนส่ง",
    "note": "ส่งของบิ๊กซีบางใหญ่",
    "amount": 420
  },
  {
    "date": "08 พ.ค.",
    "category": "ค่าน้ำ",
    "note": "ค่าน้ำประปา",
    "amount": 380
  },
  {
    "date": "05 พ.ค.",
    "category": "ค่าจ้าง",
    "note": "ค่าจ้างพี่นก",
    "amount": 4500
  },
  {
    "date": "03 พ.ค.",
    "category": "ของใช้สิ้นเปลือง",
    "note": "ถุงซีลร้อน",
    "amount": 1200
  }
];

// 📝 ซื้อวัตถุดิบ
const PURCHASES = [
  {
    "date": "18 พ.ค.",
    "code": "PO-260518-2",
    "supplier": "Makro",
    "raw": "R03",
    "qty": 50,
    "unit": "kg",
    "total": 1500
  },
  {
    "date": "18 พ.ค.",
    "code": "PO-260518-1",
    "supplier": "Makro",
    "raw": "R03",
    "qty": 100,
    "unit": "kg",
    "total": 3000
  },
  {
    "date": "17 พ.ค.",
    "code": "PO-260517-PK",
    "supplier": "บรรจุภัณฑ์เพื่อนแท้",
    "raw": "PK60",
    "qty": 5000,
    "unit": "กรัม",
    "total": 9000
  },
  {
    "date": "17 พ.ค.",
    "code": "PO-260517",
    "supplier": "น้ำตาลวังขนาย",
    "raw": "R01",
    "qty": 25000,
    "unit": "กรัม",
    "total": 675
  },
  {
    "date": "16 พ.ค.",
    "code": "PO-260516",
    "supplier": "ปรุงทิพย์",
    "raw": "R02",
    "qty": 50000,
    "total": 650
  },
  {
    "date": "14 พ.ค.",
    "code": "PO-260514",
    "supplier": "อายิโนะโมะโต๊ะ",
    "raw": "R03",
    "qty": 100000,
    "total": 10000
  },
  {
    "date": "12 พ.ค.",
    "code": "PO-260512",
    "supplier": "Makro",
    "raw": "R04",
    "qty": 25000,
    "total": 2563
  },
  {
    "date": "10 พ.ค.",
    "code": "PO-260510",
    "supplier": "อายิโนะโมะโต๊ะ",
    "raw": "R05",
    "qty": 50000,
    "total": 1940
  },
  {
    "date": "08 พ.ค.",
    "code": "PO-260508",
    "supplier": "อดินพ ผงสี",
    "raw": "R06",
    "qty": 100000,
    "total": 35000
  },
  {
    "date": "05 พ.ค.",
    "code": "PO-260505",
    "supplier": "Makro (ARO)",
    "raw": "R07",
    "qty": 25000,
    "total": 825
  },
  {
    "date": "03 พ.ค.",
    "code": "PO-260503",
    "supplier": "น้ำตาลวังขนาย",
    "raw": "R01",
    "qty": 50000,
    "total": 1350
  }
];

// 📝 รายการขาย
const SALES = [
  {
    "date": "18 พ.ค.",
    "code": "S-260518-1",
    "customer": "ร้านโชห่วยป้าสมศรี",
    "product": "P06",
    "qty": 60,
    "total": 1140
  },
  {
    "date": "18 พ.ค.",
    "code": "S-260518-2",
    "customer": "ร้านอาหารสมบูรณ์",
    "product": "P25",
    "qty": 67,
    "total": 1273
  },
  {
    "date": "18 พ.ค.",
    "code": "S-260518-3",
    "customer": "คุณนุ้ย ไก่ย่าง",
    "product": "P11",
    "qty": 74,
    "total": 1406
  },
  {
    "date": "17 พ.ค.",
    "code": "S-260517-4",
    "customer": "ร้านสะดวกซื้อพี่นิด",
    "product": "P01",
    "qty": 81,
    "total": 1539
  },
  {
    "date": "17 พ.ค.",
    "code": "S-260517-5",
    "customer": "ตลาดสี่มุมเมือง",
    "product": "P15",
    "qty": 88,
    "total": 1672
  },
  {
    "date": "17 พ.ค.",
    "code": "S-260517-6",
    "customer": "ลูกค้าหน้าร้าน",
    "product": "P03",
    "qty": 55,
    "total": 2695
  },
  {
    "date": "16 พ.ค.",
    "code": "S-260516-7",
    "customer": "ร้านไก่ย่างเฮียจิ๋ว",
    "product": "P19",
    "qty": 102,
    "total": 1938
  },
  {
    "date": "16 พ.ค.",
    "code": "S-260516-8",
    "customer": "คุณตุ๋ย ไก่ย่างสุพรรณ",
    "product": "P07",
    "qty": 29,
    "total": 1131
  },
  {
    "date": "15 พ.ค.",
    "code": "S-260515-9",
    "customer": "บิ๊กซี บางใหญ่",
    "product": "P26",
    "qty": 36,
    "total": 1404
  },
  {
    "date": "15 พ.ค.",
    "code": "S-260515-10",
    "customer": "ครัวร้านโจ๊กสามย่าน",
    "product": "P12",
    "qty": 43,
    "total": 1677
  },
  {
    "date": "14 พ.ค.",
    "code": "S-260514-11",
    "customer": "แม็คโครแจ้งวัฒนะ",
    "product": "P02",
    "qty": 50,
    "total": 1950
  },
  {
    "date": "13 พ.ค.",
    "code": "S-260513-12",
    "customer": "ร้านโชห่วยป้าสมศรี",
    "product": "P16",
    "qty": 57,
    "total": 2223
  },
  {
    "date": "12 พ.ค.",
    "code": "S-260512-13",
    "customer": "ร้านอาหารสมบูรณ์",
    "product": "P06",
    "qty": 144,
    "total": 2736
  },
  {
    "date": "10 พ.ค.",
    "code": "S-260510-14",
    "customer": "คุณนุ้ย ไก่ย่าง",
    "product": "P25",
    "qty": 151,
    "total": 2869
  },
  {
    "date": "08 พ.ค.",
    "code": "S-260508-15",
    "customer": "ร้านสะดวกซื้อพี่นิด",
    "product": "P11",
    "qty": 158,
    "total": 3002
  },
  {
    "date": "05 พ.ค.",
    "code": "S-260505-16",
    "customer": "ตลาดสี่มุมเมือง",
    "product": "P01",
    "qty": 165,
    "total": 3135
  },
  {
    "date": "03 พ.ค.",
    "code": "S-260503-17",
    "customer": "ลูกค้าหน้าร้าน",
    "product": "P15",
    "qty": 172,
    "total": 3268
  },
  {
    "date": "01 พ.ค.",
    "code": "S-260501-18",
    "customer": "ร้านไก่ย่างเฮียจิ๋ว",
    "product": "P03",
    "qty": 59,
    "total": 2891
  }
];

// ⊕ ปรับปรุงสินค้าพร้อมขาย
const ADJ_FINISHED = [
  {
    "date": "16 พ.ค.",
    "product": "P02",
    "qty": -3,
    "reason": "ซองรั่ว ทิ้ง",
    "by": "ยายปู"
  },
  {
    "date": "12 พ.ค.",
    "product": "P01",
    "qty": -8,
    "reason": "หมดอายุ",
    "by": "พี่นิด"
  },
  {
    "date": "07 พ.ค.",
    "product": "P04",
    "qty": 2,
    "reason": "นับสต๊อกใหม่",
    "by": "ยายปู"
  }
];

// ⊕ ปรับปรุงวัตถุดิบ
const ADJ_RAW = [
  {
    "date": "17 พ.ค.",
    "raw": "R03",
    "qty": -50,
    "reason": "หกระหว่างชั่ง",
    "by": "พี่นิด"
  },
  {
    "date": "13 พ.ค.",
    "raw": "PK60",
    "qty": -25,
    "reason": "ซองพิมพ์ผิด ทิ้ง",
    "by": "ยายปู"
  },
  {
    "date": "08 พ.ค.",
    "raw": "R02",
    "qty": 100,
    "reason": "นับสต๊อกใหม่",
    "by": "ยายปู"
  }
];

// 📤 เบิกของ — เบิกวัตถุดิบ/สินค้าออกจากคลัง
const WITHDRAWALS = [
  {
    "date": "18 พ.ค.",
    "iso": "2026-05-18",
    "code": "WD-260518-1",
    "kind": "raw",
    "item": "R19",
    "qty": 3000,
    "purpose": "ใช้ในการผลิต",
    "by": "พี่นิด"
  },
  {
    "date": "18 พ.ค.",
    "iso": "2026-05-18",
    "code": "WD-260518-2",
    "kind": "raw",
    "item": "PK60",
    "qty": 500,
    "purpose": "ใช้ในการผลิต",
    "by": "ยายปู"
  },
  {
    "date": "17 พ.ค.",
    "iso": "2026-05-17",
    "code": "WD-260517-1",
    "kind": "finished",
    "item": "P06",
    "qty": 12,
    "purpose": "ตัวอย่างให้ลูกค้า",
    "by": "ยายปู"
  },
  {
    "date": "16 พ.ค.",
    "iso": "2026-05-16",
    "code": "WD-260516-1",
    "kind": "raw",
    "item": "R04",
    "qty": 5000,
    "purpose": "ใช้ในการผลิต",
    "by": "พี่นก"
  },
  {
    "date": "15 พ.ค.",
    "iso": "2026-05-15",
    "code": "WD-260515-1",
    "kind": "finished",
    "item": "P15",
    "qty": 6,
    "purpose": "ออกบูธ/งานแสดงสินค้า",
    "by": "พี่นิด"
  },
  {
    "date": "13 พ.ค.",
    "iso": "2026-05-13",
    "code": "WD-260513-1",
    "kind": "raw",
    "item": "R74",
    "qty": 1200,
    "purpose": "ใช้ในการผลิต",
    "by": "พี่นก"
  }
];

const WITHDRAW_REASONS = ["ใช้ในการผลิต","ตัวอย่างให้ลูกค้า","ออกบูธ/งานแสดงสินค้า","ใช้ภายในกิจการ","ของแถม","อื่น ๆ"];

// 📦 สต๊อกสินค้าพร้อมขาย (computed)
const FINISHED_STOCK = [
  {
    "product": "P01",
    "inHand": 320,
    "reorder": 240
  },
  {
    "product": "P02",
    "inHand": 161,
    "reorder": 90
  },
  {
    "product": "P03",
    "inHand": 202,
    "reorder": 90
  },
  {
    "product": "P04",
    "inHand": 41,
    "reorder": 15
  },
  {
    "product": "P05",
    "inHand": 24,
    "reorder": 8
  },
  {
    "product": "P06",
    "inHand": 868,
    "reorder": 240
  },
  {
    "product": "P07",
    "inHand": 367,
    "reorder": 90
  },
  {
    "product": "P08",
    "inHand": 408,
    "reorder": 90
  },
  {
    "product": "P09",
    "inHand": 25,
    "reorder": 15
  },
  {
    "product": "P10",
    "inHand": 16,
    "reorder": 8
  },
  {
    "product": "P11",
    "inHand": 616,
    "reorder": 240
  },
  {
    "product": "P12",
    "inHand": 272,
    "reorder": 90
  },
  {
    "product": "P13",
    "inHand": 313,
    "reorder": 90
  },
  {
    "product": "P14",
    "inHand": 59,
    "reorder": 15
  },
  {
    "product": "P15",
    "inHand": 1054,
    "reorder": 240
  },
  {
    "product": "P16",
    "inHand": 137,
    "reorder": 90
  },
  {
    "product": "P17",
    "inHand": 178,
    "reorder": 90
  },
  {
    "product": "P18",
    "inHand": 36,
    "reorder": 15
  },
  {
    "product": "P19",
    "inHand": 693,
    "reorder": 240
  },
  {
    "product": "P20",
    "inHand": 301,
    "reorder": 90
  },
  {
    "product": "P21",
    "inHand": 912,
    "reorder": 240
  },
  {
    "product": "P22",
    "inHand": 383,
    "reorder": 90
  },
  {
    "product": "P23",
    "inHand": 124,
    "reorder": 90
  },
  {
    "product": "P24",
    "inHand": 28,
    "reorder": 15
  },
  {
    "product": "P25",
    "inHand": 550,
    "reorder": 240
  },
  {
    "product": "P26",
    "inHand": 248,
    "reorder": 90
  },
  {
    "product": "P27",
    "inHand": 289,
    "reorder": 90
  }
];

// 🥩 วัตถุดิบคงเหลือ
const RAW_STOCK = [
  {
    "raw": "R01",
    "inHand": 9000,
    "reorder": 15000
  },
  {
    "raw": "R02",
    "inHand": 15390,
    "reorder": 15000
  },
  {
    "raw": "R03",
    "inHand": 21780,
    "reorder": 15000
  },
  {
    "raw": "R04",
    "inHand": 9000,
    "reorder": 15000
  },
  {
    "raw": "R05",
    "inHand": 34560,
    "reorder": 15000
  },
  {
    "raw": "R06",
    "inHand": 10950,
    "reorder": 15000
  },
  {
    "raw": "R07",
    "inHand": 17340,
    "reorder": 15000
  },
  {
    "raw": "R08",
    "inHand": 23730,
    "reorder": 15000
  },
  {
    "raw": "R09",
    "inHand": 30120,
    "reorder": 15000
  },
  {
    "raw": "R10",
    "inHand": 36510,
    "reorder": 15000
  },
  {
    "raw": "R11",
    "inHand": 15390,
    "reorder": 15000
  },
  {
    "raw": "R12",
    "inHand": 19290,
    "reorder": 15000
  },
  {
    "raw": "R13",
    "inHand": 25680,
    "reorder": 15000
  },
  {
    "raw": "R14",
    "inHand": 32070,
    "reorder": 15000
  },
  {
    "raw": "R15",
    "inHand": 38460,
    "reorder": 15000
  },
  {
    "raw": "R16",
    "inHand": 3960,
    "reorder": 4000
  },
  {
    "raw": "R17",
    "inHand": 34560,
    "reorder": 15000
  },
  {
    "raw": "R18",
    "inHand": 7368,
    "reorder": 4000
  },
  {
    "raw": "R19",
    "inHand": 5808,
    "reorder": 4000
  },
  {
    "raw": "R20",
    "inHand": 21240,
    "reorder": 15000
  },
  {
    "raw": "R21",
    "inHand": 4480,
    "reorder": 4000
  },
  {
    "raw": "R22",
    "inHand": 23190,
    "reorder": 15000
  },
  {
    "raw": "R23",
    "inHand": 17340,
    "reorder": 15000
  },
  {
    "raw": "R24",
    "inHand": 35970,
    "reorder": 15000
  },
  {
    "raw": "R25",
    "inHand": 12360,
    "reorder": 15000
  },
  {
    "raw": "R26",
    "inHand": 18750,
    "reorder": 15000
  },
  {
    "raw": "R27",
    "inHand": 32070,
    "reorder": 15000
  },
  {
    "raw": "R28",
    "inHand": 31530,
    "reorder": 15000
  },
  {
    "raw": "R29",
    "inHand": 37920,
    "reorder": 15000
  },
  {
    "raw": "R30",
    "inHand": 14310,
    "reorder": 15000
  },
  {
    "raw": "R31",
    "inHand": 38460,
    "reorder": 15000
  },
  {
    "raw": "R32",
    "inHand": 27090,
    "reorder": 15000
  },
  {
    "raw": "R33",
    "inHand": 33480,
    "reorder": 15000
  },
  {
    "raw": "R34",
    "inHand": 9870,
    "reorder": 15000
  },
  {
    "raw": "R35",
    "inHand": 824,
    "reorder": 1000
  },
  {
    "raw": "R36",
    "inHand": 18750,
    "reorder": 15000
  },
  {
    "raw": "R37",
    "inHand": 7744,
    "reorder": 4000
  },
  {
    "raw": "R38",
    "inHand": 23730,
    "reorder": 15000
  },
  {
    "raw": "R39",
    "inHand": 7368,
    "reorder": 4000
  },
  {
    "raw": "R40",
    "inHand": 6704,
    "reorder": 4000
  },
  {
    "raw": "R41",
    "inHand": 6560,
    "reorder": 4000
  },
  {
    "raw": "R42",
    "inHand": 8264,
    "reorder": 4000
  },
  {
    "raw": "R43",
    "inHand": 9968,
    "reorder": 4000
  },
  {
    "raw": "R44",
    "inHand": 918,
    "reorder": 1000
  },
  {
    "raw": "R45",
    "inHand": 30120,
    "reorder": 15000
  },
  {
    "raw": "R46",
    "inHand": 1770,
    "reorder": 1000
  },
  {
    "raw": "R47",
    "inHand": 2196,
    "reorder": 1000
  },
  {
    "raw": "R48",
    "inHand": 2434,
    "reorder": 1000
  },
  {
    "raw": "R49",
    "inHand": 12900,
    "reorder": 15000
  },
  {
    "raw": "R50",
    "inHand": 5896,
    "reorder": 4000
  },
  {
    "raw": "R51",
    "inHand": 7600,
    "reorder": 4000
  },
  {
    "raw": "R52",
    "inHand": 9304,
    "reorder": 4000
  },
  {
    "raw": "R53",
    "inHand": 16800,
    "reorder": 15000
  },
  {
    "raw": "R54",
    "inHand": 23190,
    "reorder": 15000
  },
  {
    "raw": "R55",
    "inHand": 1604,
    "reorder": 1000
  },
  {
    "raw": "R56",
    "inHand": 1972,
    "reorder": 1000
  },
  {
    "raw": "R57",
    "inHand": 9824,
    "reorder": 4000
  },
  {
    "raw": "R58",
    "inHand": 3528,
    "reorder": 4000
  },
  {
    "raw": "R59",
    "inHand": 5232,
    "reorder": 4000
  },
  {
    "raw": "R60",
    "inHand": 6936,
    "reorder": 4000
  },
  {
    "raw": "R61",
    "inHand": 2160,
    "reorder": 1000
  },
  {
    "raw": "R62",
    "inHand": 1286,
    "reorder": 1000
  },
  {
    "raw": "R63",
    "inHand": 1012,
    "reorder": 1000
  },
  {
    "raw": "R64",
    "inHand": 1438,
    "reorder": 1000
  },
  {
    "raw": "R65",
    "inHand": 1864,
    "reorder": 1000
  },
  {
    "raw": "R66",
    "inHand": 2290,
    "reorder": 1000
  },
  {
    "raw": "R67",
    "inHand": 2864,
    "reorder": 4000
  },
  {
    "raw": "R68",
    "inHand": 25680,
    "reorder": 15000
  },
  {
    "raw": "R69",
    "inHand": 1568,
    "reorder": 1000
  },
  {
    "raw": "R70",
    "inHand": 730,
    "reorder": 1000
  },
  {
    "raw": "R71",
    "inHand": 9680,
    "reorder": 4000
  },
  {
    "raw": "R72",
    "inHand": 3384,
    "reorder": 4000
  },
  {
    "raw": "R73",
    "inHand": 5088,
    "reorder": 4000
  },
  {
    "raw": "R74",
    "inHand": 7512,
    "reorder": 4000
  },
  {
    "raw": "R75",
    "inHand": 8496,
    "reorder": 4000
  },
  {
    "raw": "R76",
    "inHand": 10200,
    "reorder": 4000
  },
  {
    "raw": "R77",
    "inHand": 3904,
    "reorder": 4000
  },
  {
    "raw": "R78",
    "inHand": 5608,
    "reorder": 4000
  },
  {
    "raw": "R79",
    "inHand": 7312,
    "reorder": 4000
  },
  {
    "raw": "R80",
    "inHand": 35970,
    "reorder": 15000
  },
  {
    "raw": "R81",
    "inHand": 14850,
    "reorder": 15000
  },
  {
    "raw": "R82",
    "inHand": 16590,
    "reorder": 15000
  },
  {
    "raw": "R83",
    "inHand": 22980,
    "reorder": 15000
  },
  {
    "raw": "R84",
    "inHand": 7832,
    "reorder": 4000
  },
  {
    "raw": "R85",
    "inHand": 9536,
    "reorder": 4000
  },
  {
    "raw": "R86",
    "inHand": 10410,
    "reorder": 15000
  },
  {
    "raw": "R87",
    "inHand": 4944,
    "reorder": 4000
  },
  {
    "raw": "R88",
    "inHand": 6648,
    "reorder": 4000
  },
  {
    "raw": "R89",
    "inHand": 9072,
    "reorder": 4000
  },
  {
    "raw": "R90",
    "inHand": 2514,
    "reorder": 1000
  },
  {
    "raw": "R91",
    "inHand": 3760,
    "reorder": 4000
  },
  {
    "raw": "PK30",
    "inHand": 4800,
    "reorder": 3000
  },
  {
    "raw": "PK60",
    "inHand": 1840,
    "reorder": 3000
  },
  {
    "raw": "PK100",
    "inHand": 3200,
    "reorder": 2000
  },
  {
    "raw": "PK650",
    "inHand": 480,
    "reorder": 500
  },
  {
    "raw": "PK1000",
    "inHand": 280,
    "reorder": 200
  }
];

// 📈 รายงานขายรายเดือน
const MONTHLY_SALES = [
  {
    "m": "มิ.ย. 68",
    "revenue": 38400,
    "cost": 24200,
    "expense": 6800
  },
  {
    "m": "ก.ค. 68",
    "revenue": 42100,
    "cost": 26800,
    "expense": 7200
  },
  {
    "m": "ส.ค. 68",
    "revenue": 36800,
    "cost": 23200,
    "expense": 6400
  },
  {
    "m": "ก.ย. 68",
    "revenue": 45200,
    "cost": 28400,
    "expense": 7800
  },
  {
    "m": "ต.ค. 68",
    "revenue": 48600,
    "cost": 30200,
    "expense": 8100
  },
  {
    "m": "พ.ย. 68",
    "revenue": 52800,
    "cost": 32600,
    "expense": 8400
  },
  {
    "m": "ธ.ค. 68",
    "revenue": 64200,
    "cost": 38400,
    "expense": 9200
  },
  {
    "m": "ม.ค. 69",
    "revenue": 41800,
    "cost": 26200,
    "expense": 7800
  },
  {
    "m": "ก.พ. 69",
    "revenue": 46400,
    "cost": 28800,
    "expense": 7600
  },
  {
    "m": "มี.ค. 69",
    "revenue": 51200,
    "cost": 31600,
    "expense": 8200
  },
  {
    "m": "เม.ย. 69",
    "revenue": 54800,
    "cost": 33800,
    "expense": 8800
  },
  {
    "m": "พ.ค. 69",
    "revenue": 37949,
    "cost": 23528,
    "expense": 15550,
    "partial": true
  }
];

// 📈 รายงานขายรายปี
const YEARLY_SALES = [
  {
    "y": "2566",
    "revenue": 312800,
    "cost": 198400,
    "expense": 64200,
    "products": 12
  },
  {
    "y": "2567",
    "revenue": 428600,
    "cost": 268400,
    "expense": 78600,
    "products": 18
  },
  {
    "y": "2568",
    "revenue": 564200,
    "cost": 348800,
    "expense": 92400,
    "products": 24
  },
  {
    "y": "2569 (YTD)",
    "revenue": 216940,
    "cost": 134480,
    "expense": 46550,
    "products": 27,
    "partial": true
  }
];

// helpers
const fmt = (n) => Number(n).toLocaleString("en-US");
const baht = (n) => "฿" + Number(n).toLocaleString("en-US", { maximumFractionDigits: 2 });
const baht0 = (n) => "฿" + Math.round(Number(n)).toLocaleString("en-US");
const findRaw = (code) => RAW.find(r => r.code === code);
const findProduct = (code) => MENU.find(p => p.code === code);

Object.assign(window, {
  TODAY, MONTH_LABEL,
  MENU, RAW, RECIPES, PRODUCTIONS,
  EXPENSES, PURCHASES, SALES, ADJ_FINISHED, ADJ_RAW, WITHDRAWALS, WITHDRAW_REASONS,
  FINISHED_STOCK, RAW_STOCK,
  MONTHLY_SALES, YEARLY_SALES,
  fmt, baht, baht0, findRaw, findProduct,
});

// 📖 โหลดรายการสินค้าแบบสด — รวม MENU พื้นฐาน + ที่แก้ไข/เพิ่มใน erp_menu − ที่ลบใน erp_menu_deleted
// ใช้ร่วมกันทุกหน้าที่ต้องเลือกสินค้า (ใบสั่งขาย / ใบเสนอราคา) เพื่อให้สะท้อนการแก้ไขในหน้ารายการสินค้า
function loadMenuLive() {
  const base = (typeof MENU !== "undefined") ? MENU : [];
  try {
    const saved = localStorage.getItem("erp_menu");
    const savedArr = saved ? JSON.parse(saved) : [];
    let deleted = [];
    try { deleted = JSON.parse(localStorage.getItem("erp_menu_deleted") || "[]"); } catch (e) {}
    const map = new Map();
    base.forEach((p) => map.set(p.code, p));
    savedArr.forEach((p) => map.set(p.code, p));   // ทับด้วยค่าที่แก้ไข/เพิ่ม
    deleted.forEach((code) => map.delete(code));   // ตัดรายการที่ลบ
    return Array.from(map.values());
  } catch (e) {
    return base;
  }
}
window.loadMenuLive = loadMenuLive;

// 🥩 โหลดวัตถุดิบแบบสด — รวม RAW พื้นฐาน + ที่แก้ไข/เพิ่มใน erp_raw
// ใช้ในหน้าใบสั่งซื้อ (เลือก/สแกน/ค้นหาวัตถุดิบ)
function loadRawLive() {
  const base = (typeof RAW !== "undefined") ? RAW : [];
  try {
    const saved = localStorage.getItem("erp_raw");
    if (saved) {
      const arr = JSON.parse(saved);
      if (Array.isArray(arr) && arr.length) return arr;
    }
  } catch (e) {}
  return base;
}
window.loadRawLive = loadRawLive;
