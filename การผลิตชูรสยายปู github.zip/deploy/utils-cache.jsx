// Data cache + lazy loading utility
class DataCache {
  constructor() {
    this.cache = {};
    this.timestamps = {};
    this.TTL = 5 * 60 * 1000; // 5 minutes
  }

  get(key) {
    const now = Date.now();
    if (this.cache[key] && (now - this.timestamps[key]) < this.TTL) {
      return this.cache[key];
    }
    return null;
  }

  set(key, data) {
    this.cache[key] = data;
    this.timestamps[key] = Date.now();
  }

  invalidate(key) {
    delete this.cache[key];
    delete this.timestamps[key];
  }

  clear() {
    this.cache = {};
    this.timestamps = {};
  }
}

// Memoization for expensive calculations
const useMemoData = (key, fn, deps = []) => {
  const cacheRef = React.useRef(null);
  const depsRef = React.useRef(deps);

  if (!cacheRef.current) {
    cacheRef.current = fn();
  } else if (JSON.stringify(deps) !== JSON.stringify(depsRef.current)) {
    cacheRef.current = fn();
    depsRef.current = deps;
  }

  return cacheRef.current;
};

// Lazy load data with pagination
const useLazyLoadData = (storageKey, pageSize = 50) => {
  const [data, setData] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [total, setTotal] = React.useState(0);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      const allData = JSON.parse(localStorage.getItem(storageKey) || '[]');
      setTotal(allData.length);
      
      const startIdx = page * pageSize;
      const pageData = allData.slice(startIdx, startIdx + pageSize);
      setData(pageData);
      setLoading(false);
    }, 50); // simulate async load
  }, [page, storageKey, pageSize]);

  const loadMore = () => setPage(p => p + 1);
  const reset = () => setPage(0);

  return {
    data,
    page,
    total,
    pageSize,
    loading,
    hasMore: (page + 1) * pageSize < total,
    loadMore,
    reset
  };
};

// Virtual table for large datasets
const VirtualTable = ({ data, columns, height = 400, rowHeight = 45 }) => {
  const [scrollTop, setScrollTop] = React.useState(0);
  const containerRef = React.useRef(null);

  const visibleCount = Math.ceil(height / rowHeight) + 2;
  const startIdx = Math.max(0, Math.floor(scrollTop / rowHeight) - 1);
  const endIdx = Math.min(startIdx + visibleCount, data.length);
  const visibleRows = data.slice(startIdx, endIdx);

  return (
    <div
      ref={containerRef}
      style={{
        height,
        overflow: 'auto',
        border: '1px solid var(--border)',
        borderRadius: '8px',
        fontSize: '13px'
      }}
      onScroll={(e) => setScrollTop(e.target.scrollTop)}
    >
      {/* Header */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: columns.map(c => c.width || '1fr').join(' '),
          gap: '0',
          padding: '10px 14px',
          background: 'var(--surface-2)',
          borderBottom: '1px solid var(--border)',
          position: 'sticky',
          top: 0,
          zIndex: 10,
          fontWeight: 600,
          fontSize: '11px',
          textTransform: 'uppercase',
          color: 'var(--muted)',
          letterSpacing: '0.06em'
        }}
      >
        {columns.map(col => (
          <div key={col.key} style={{whiteSpace: 'nowrap'}}>{col.label}</div>
        ))}
      </div>

      {/* Virtual rows */}
      <div style={{height: data.length * rowHeight, position: 'relative'}}>
        {visibleRows.map((row, visIdx) => {
          const actualIdx = startIdx + visIdx;
          return (
            <div
              key={actualIdx}
              style={{
                position: 'absolute',
                top: actualIdx * rowHeight,
                left: 0,
                right: 0,
                height: rowHeight,
                display: 'grid',
                gridTemplateColumns: columns.map(c => c.width || '1fr').join(' '),
                gap: '0',
                borderBottom: '1px solid var(--border)',
                alignItems: 'center',
                padding: '8px 14px',
                backgroundColor: actualIdx % 2 === 0 ? 'var(--surface)' : 'rgba(0,0,0,0.01)'
              }}
            >
              {columns.map(col => (
                <div key={col.key} style={{overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'}}>
                  {col.render ? col.render(row[col.key], row) : row[col.key]}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
};

// Virtual list for large tables (simple implementation)
const VirtualList = ({ items, itemHeight = 50, height = 400, renderItem }) => {
  const [scrollTop, setScrollTop] = React.useState(0);
  const containerRef = React.useRef(null);

  const visibleCount = Math.ceil(height / itemHeight);
  const startIdx = Math.floor(scrollTop / itemHeight);
  const endIdx = Math.min(startIdx + visibleCount + 1, items.length);
  const visibleItems = items.slice(startIdx, endIdx);

  return (
    <div
      ref={containerRef}
      style={{
        height,
        overflow: 'auto',
        border: '1px solid var(--border)',
        borderRadius: '8px'
      }}
      onScroll={(e) => setScrollTop(e.target.scrollTop)}
    >
      <div style={{height: items.length * itemHeight, position: 'relative'}}>
        {visibleItems.map((item, idx) => (
          <div
            key={startIdx + idx}
            style={{
              position: 'absolute',
              top: (startIdx + idx) * itemHeight,
              left: 0,
              right: 0,
              height: itemHeight
            }}
          >
            {renderItem(item, startIdx + idx)}
          </div>
        ))}
      </div>
    </div>
  );
};

// ===== Live store =====
// ทำให้ทุกหน้าจอ "เห็นข้อมูลใหม่ทันที" หลังบันทึก/แก้/ลบ โดยไม่ต้องรีเฟรช
// วิธีการ: ดักจับการเขียน localStorage ทุกครั้ง แล้วยิงสัญญาณ "erp:store-change"
// — ยิงเฉพาะเมื่อค่าจริง ๆ เปลี่ยน เพื่อกันลูปไม่รู้จบจากหน้าที่เขียนค่าเดิมตอนโหลด
(function installLiveStore() {
  if (typeof window === "undefined" || window.__erpLiveStoreInstalled) return;
  window.__erpLiveStoreInstalled = true;

  const ls = window.localStorage;
  const origSet = ls.setItem.bind(ls);
  const origRemove = ls.removeItem.bind(ls);
  const origClear = ls.clear.bind(ls);

  // ตัวกันลูป: ถ้ายิงถี่เกินไปในช่วงสั้น ๆ ให้พักชั่วคราว (กันแอปค้าง)
  let burst = [];
  let cooldownUntil = 0;
  let pending = false;

  const notify = () => {
    const now = Date.now();
    if (now < cooldownUntil) return;
    burst = burst.filter((t) => now - t < 1000);
    burst.push(now);
    if (burst.length > 40) {
      cooldownUntil = now + 1500;
      burst = [];
      console.warn("[erp:live] เขียนข้อมูลถี่ผิดปกติ — หยุดอัปเดตอัตโนมัติชั่วคราว");
      return;
    }
    if (pending) return;          // รวมหลายการเขียนใน save เดียวให้เหลือสัญญาณเดียว
    pending = true;
    Promise.resolve().then(() => {
      pending = false;
      try { window.dispatchEvent(new CustomEvent("erp:store-change")); } catch (e) {}
    });
  };

  ls.setItem = function (key, value) {
    let changed = true;
    try { changed = ls.getItem(key) !== String(value); } catch (e) {}
    origSet(key, value);
    if (changed) notify();
  };
  ls.removeItem = function (key) {
    let existed = false;
    try { existed = ls.getItem(key) !== null; } catch (e) {}
    origRemove(key);
    if (existed) notify();
  };
  ls.clear = function () {
    origClear();
    notify();
  };
})();

// Hook: คืนค่าตัวเลขที่เพิ่มขึ้นทุกครั้งที่ข้อมูลเปลี่ยน — ใช้บังคับให้คอมโพเนนต์โหลดใหม่
const useStoreVersion = () => {
  const [v, setV] = React.useState(0);
  React.useEffect(() => {
    const bump = () => setV((x) => x + 1);
    window.addEventListener("erp:store-change", bump); // เปลี่ยนในแท็บนี้
    window.addEventListener("storage", bump);          // เปลี่ยนจากแท็บอื่น
    return () => {
      window.removeEventListener("erp:store-change", bump);
      window.removeEventListener("storage", bump);
    };
  }, []);
  return v;
};

// Global data cache instance
const dataCache = new DataCache();

Object.assign(window, {
  DataCache,
  dataCache,
  useMemoData,
  useLazyLoadData,
  useStoreVersion,
  VirtualList
});
